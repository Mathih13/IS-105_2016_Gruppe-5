import sys

sys.path.append('/foo/bar/mock-0.3.1')

from canvas import ourCanvas