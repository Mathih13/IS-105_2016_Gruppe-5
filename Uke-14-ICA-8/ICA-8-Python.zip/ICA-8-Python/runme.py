from mainFrame import *

'''THIS PYTHON FILE "STARTS" THE PROGRAM!'''


# Create the Tkinter frame, give it a title
# then enter mainloop.
root = Tk()
frame = ourFrame(2000, 1500, root)
root.title('River Crossing')
root.mainloop()
