# This file collects all classes and data
# that falls under the "view" part of the 
# model-view-controller system

# IMPORT THIS WHEN YOU WANT TO GRAB ANYTHING
# FROM EITHER OF THE CLASSES BELOW

from Tkinter import *
from WorldObject import *


from canvas import *
from mainFrame import *