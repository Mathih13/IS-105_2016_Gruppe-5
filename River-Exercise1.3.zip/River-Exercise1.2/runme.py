from sm import *
from river import *
from interaction import *


#This script acts as the "front" for easy testing and running. All you have to do is run this to activate the main loop.

'''Hierarcy:'''
#interaction.py
#river.py
#sm.py
    